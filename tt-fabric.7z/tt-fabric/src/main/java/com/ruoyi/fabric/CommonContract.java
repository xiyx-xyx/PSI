package com.ruoyi.fabric;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.hyperledger.fabric.client.Contract;
import org.hyperledger.fabric.client.Gateway;
import org.hyperledger.fabric.client.GatewayException;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * author he peng
 * date 2022/1/22 21:34
 */


@Slf4j
@AllArgsConstructor
@Component("CommonContract")
public class CommonContract {
    private Gateway gateway;

    private Contract contract;
    private HyperLedgerFabricProperties hyperLedgerFabricProperties;



    public Map<String, Object> arbitration(String d, String z, String o, String e) throws GatewayException {
        Map<String, Object> result = Maps.newConcurrentMap();
        byte[] common = contract.evaluateTransaction("arbitration", d, z, o, e);
        result.put("payload", StringUtils.newStringUtf8(common));
        result.put("status", "ok");

        return result;
    }

    public Map<String, Object> queryByKey(String key) throws GatewayException {

        Map<String, Object> result = Maps.newConcurrentMap();
        byte[] common = contract.evaluateTransaction("queryByKey", key);



        result.put("payload", StringUtils.newStringUtf8(common));
        result.put("status", "ok");

        return result;
    }

    public Map<String, Object> create(String id, String json) throws Exception {

        Map<String, Object> result = Maps.newConcurrentMap();

        byte[] bytes = contract.submitTransaction("put", id, json);

        result.put("payload", StringUtils.newStringUtf8(bytes));
        result.put("status", "ok");
        return result;
    }


}
