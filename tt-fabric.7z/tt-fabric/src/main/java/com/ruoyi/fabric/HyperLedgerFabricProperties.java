package com.ruoyi.fabric;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * author he peng
 * date 2022/1/22 21:24
 */

@Data
@Component
public class HyperLedgerFabricProperties {

    String mspId = "Org1MSP";
    String prefix = "D:/organizations/";

    String networkConnectionConfigPath = prefix + "org1TestNetworkConnection.json";

    String certificatePath = prefix + "peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/signcerts/cert.pem";

    String privateKeyPath = prefix + "peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/keystore/priv_sk";

    String tlsCertPath = prefix + "peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt";

    String channel = "mychannel";
}
