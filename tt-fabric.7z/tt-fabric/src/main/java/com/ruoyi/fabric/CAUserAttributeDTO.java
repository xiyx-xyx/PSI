package com.ruoyi.fabric;

import lombok.Data;

/**
 * @author he peng
 * @date 2022/3/11
 */

@Data
public class CAUserAttributeDTO {

    String name;

    String value;
}
