package com.ruoyi.fabric;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.hyperledger.fabric.client.Contract;
import org.hyperledger.fabric.client.Gateway;
import org.hyperledger.fabric.client.GatewayException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;
import java.util.Random;

/**
 * author he peng
 * date 2022/1/22 21:34
 */


@Slf4j
@AllArgsConstructor
@Component("CatContractController")
public class CatContractController {
    private Gateway gateway;

    private Contract contract;
    private HyperLedgerFabricProperties hyperLedgerFabricProperties;



    public Map<String, Object> queryCatByKey(String key) throws GatewayException {

        Map<String, Object> result = Maps.newConcurrentMap();
        byte[] cat = contract.evaluateTransaction("queryCat", key);

        result.put("payload", StringUtils.newStringUtf8(cat));
        result.put("status", "ok");

        return result;
    }

    public Map<String, Object> createCat(CatDTO cat) throws Exception {

        Map<String, Object> result = Maps.newConcurrentMap();

        byte[] bytes = contract.submitTransaction("createCat", cat.getKey(), cat.getName(), String.valueOf(cat.getAge()), cat.getColor(), cat.getBreed());

        result.put("payload", StringUtils.newStringUtf8(bytes));
        result.put("status", "ok");
        return result;
    }


}
