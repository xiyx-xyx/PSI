package com.ruoyi.fabric;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * author he peng
 * date 2022/1/22 22:00
 */

@Accessors(chain = true)
public class CatDTO {

    String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    String name;

    Integer age;

    String color;

    String breed;
}
