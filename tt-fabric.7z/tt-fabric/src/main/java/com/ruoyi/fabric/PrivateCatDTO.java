package com.ruoyi.fabric;


import lombok.Data;

/**
 * author he peng
 * date 2022/1/27 18:13
 */

@Data
public class PrivateCatDTO {

    CatDTO cat;

    String collection;
}
